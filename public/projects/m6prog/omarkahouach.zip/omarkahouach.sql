-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: mariadb
-- Gegenereerd op: 07 nov 2024 om 12:57
-- Serverversie: 11.5.2-MariaDB-ubu2404
-- PHP-versie: 8.2.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omarkahouach`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `weer`
--

CREATE TABLE `weer` (
  `id` int(11) NOT NULL,
  `datum` int(25) NOT NULL,
  `weer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `artist`
--

INSERT INTO `weer` (`id`, `datum`, `weer`) VALUES
(1, 2024, '20 °C'),
(2, 2024, '22 °C'),
(3, 2024, '18 °C'),
(4, 2024, '15 °C'),
(5, 2024, '13 °C'),
(6, 2024, '17 °C'),
(7, 2024, '23 °C');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `dagen`
--

CREATE TABLE `dagen` (
  `id` int(11) NOT NULL,
  `datum` int(11) NOT NULL,
  `genre` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `dagen`
--

INSERT INTO `dagen` (`id`, `datum`, `dagen`) VALUES
(1, 2024, 'maandag'),
(2, 2024, 'dinsdag'),
(3, 2024, 'woensdag'),
(4, 2024, 'donderdag'),
(5, 2024, 'vrijdag'),
(6, 2024, 'zaterdag'),
(7, 2024, 'zondag');

-- --------------------------------------------------------

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `dagen`
--

CREATE TABLE `windkracht` (
  `id` int(11) NOT NULL,
  `datum` int(11) NOT NULL,
  `genre` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `windkracht`
--

INSERT INTO `windkracht` (`id`, `datum`, `windkracht`) VALUES
(1, 2024, '12 mph'),
(2, 2024, '10 mph'),
(3, 2024, '14 mph'),
(4, 2024, '17 mph'),
(5, 2024, '9 mph'),
(6, 2024, '15 mph'),
(7, 2024, '11 mph');

-- --------------------------------------------------------
--
-- Tabelstructuur voor tabel `WeersomstandighedenPerDag`
--

CREATE TABLE `WeersomstandighedenPerDag` (
  `id` int(11) NOT NULL,
  `datum` int(24) NOT NULL,
  `dagen` int(11) NOT NULL,
  `weer` int(11) NOT NULL,
  `windkracht` varchar(200) NOT NULL,
  `aantalgraden` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `Weersomstandighedenperdag`
--

INSERT INTO `WeersomstandighedenPerDag` (`id`, `datum`, `dagen`, `weer`,`windkracht`,) VALUES
(1, 2024, 1, 1,  '12 mph'),
(2, 2024, 2, 2, '10 mph'),
(3, 2024, 3, 3, '14 mph'),
(4, 2024, 3, 3, '17 mph'),
(5, 2024, 3, 3, '9 mph'),
(6, 2024, 3, 3, '15 mph'),
(7, 2024, 4, 4, '11 mph');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `dagen`
--
ALTER TABLE `dagen`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `weer`
--
ALTER TABLE `weer`
  ADD PRIMARY KEY (`id`);


-- Indexen voor tabel `windkracht`
--
ALTER TABLE `windkracht`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `WeersomstandighedenPerDag`
--
ALTER TABLE `WeersomstandighedenPerDag`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fork1` (`dagen`),
  ADD KEY `frok2` (`weer`);
  ADD KEY `frok` (`windkracht`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `dagen`
--
ALTER TABLE `dagen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT voor een tabel `weer`
--
ALTER TABLE `weer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;


ALTER TABLE `windkracht`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT voor een tabel `WeersomstandighedenPerDag`
--
ALTER TABLE `WeersomstandighedenPerDag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `muziek`
--
ALTER TABLE `WeersomstandighedenPerDag`
  ADD CONSTRAINT `fork2` FOREIGN KEY (`windkracht`) REFERENCES `windkracht` (`id`),
  ADD CONSTRAINT `fork1` FOREIGN KEY (`dagen`) REFERENCES `dagen` (`id`),
  ADD CONSTRAINT `frok` FOREIGN KEY (`weer`) REFERENCES `weer` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
